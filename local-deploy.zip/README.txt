Project: My Notes (React Native)
Command: npx expo start
Platform: Expo Dev Server
Status: Successfully running locally
